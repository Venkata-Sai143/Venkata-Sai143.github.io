// admin/config.js
// Copy this file to config.js and fill it in. Both values are safe to commit:
// the anon key is designed to be public, and Row Level Security is what
// actually protects your data. Never put the service_role key here.
window.PORTFOLIO_CONFIG = {
  SUPABASE_URL: 'https://YOUR-PROJECT.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOi...',
  SITE_URL: '/',            // where "Preview site" opens
};
